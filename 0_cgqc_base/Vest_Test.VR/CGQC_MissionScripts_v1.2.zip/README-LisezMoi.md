# CGQC_MissionScripts

Ouvrez les fichiers suivants:
	- cgqc_settings.sqf
	- description.ext

Pour setter tout vous trucs!