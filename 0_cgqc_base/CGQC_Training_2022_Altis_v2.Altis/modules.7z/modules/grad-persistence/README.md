# GRAD Persistence - [WIKI](https://github.com/gruppe-adler/grad-persistence/wiki) for more information

Enables you to save:

* AI units
* vehicles
* static objects (including [grad-fortifications](https://github.com/gruppe-adler/grad-fortifications))
* containers
* player equipment, inventory and health
* player money (needs grad-listBuymenu or grad-moneyMenu)
* tasks
* markers
* triggers
* variables
* time and date
